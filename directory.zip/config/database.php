<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'oldweb',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
